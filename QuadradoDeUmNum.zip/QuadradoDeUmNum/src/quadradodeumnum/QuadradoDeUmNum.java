/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quadradodeumnum;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class QuadradoDeUmNum {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float q,n;
    Scanner inputData = new Scanner(System.in);
    System.out.println("Digite um número real:");
    n = inputData.nextFloat(); 
    q = n * n;
      System.out.println("O quadrado de" + n + "é:"+ q);
    }
    
}
